# 闹钟 · DFL（原生 Android / Kotlin）

真正可靠的原生闹钟：使用 `AlarmManager.setAlarmClock` 精确唤醒，配合前台服务与全屏 Intent，锁屏/勿扰下也能弹出响铃页；重启、改时区、系统升级后自动重排。

## 功能
- 多闹钟：新建 / 编辑 / 删除 / 开关
- 重复：仅一次 / 每天 / 工作日 / 周末 / 自定义星期
- 贪睡 5/9/10/15 分钟；振动；音量渐强（30 秒）
- 铃声：默认闹钟铃声或系统铃声选择器任选
- 锁屏全屏响铃页 + 高优先级通知（含「贪睡 / 停止」按钮）
- 开机 / 时间变更 / 时区变更 / 覆盖安装后自动重排所有启用的闹钟

## 构建
- 用 **Android Studio Hedgehog 或更新** 打开本目录（`alarm-android/`），等待 Gradle 同步完成，直接 Run 到真机/模拟器（minSdk 24，targetSdk 34）。
- 命令行：先 `gradle wrapper --gradle-version 8.7` 生成包装器，再 `./gradlew assembleDebug`，产物在 `app/build/outputs/apk/debug/`。

## 权限与方案说明
- 精确唤醒用 `setAlarmClock()`：这是系统为"闹钟类应用"保留的精确通道，**各 Android 版本均允许**，因此无需申请 `SCHEDULE_EXACT_ALARM`（该权限在 Android 13+ 默认拒绝）。
- `POST_NOTIFICATIONS`：Android 13+ 运行时请求（首次进入 App 弹窗）。
- `USE_FULL_SCREEN_INTENT`：用于锁屏/后台时弹出全屏响铃页；Google Play 上架需在控制台声明"闹钟"用途（本地侧载默认授予）。
- 建议按 App 内引导**关闭电池优化**，避免国产 ROM 杀后台导致延迟。
- 前台服务类型 `mediaPlayback`：响铃期间播放声音。

## 已知限制（与厂商 ROM 相关）
- MIUI / EMUI / ColorOS 等需额外允许「自启动」「后台弹出界面」「锁屏显示」，否则可能只响通知不弹全屏。
- 关机期间错过的闹钟不会补响（开机后按下一次时间重排）。
