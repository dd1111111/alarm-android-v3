package com.dfl.alarm.util

import com.dfl.alarm.data.CnHoliday
import com.dfl.alarm.model.Alarm
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * 纯逻辑单元测试：下次触发计算 + 法定节假日/调休规则。
 * 日期断言基于 Asia/Shanghai，用国办公布的 2025/2026 调休数据验证。
 */
class AlarmTimeTest {

    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    @Before
    fun setUp() {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"))
        fmt.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
    }

    private fun at(y: Int, m: Int, d: Int, h: Int = 0, mi: Int = 0): Long {
        val c = Calendar.getInstance()
        c.set(y, m - 1, d, h, mi, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun day(y: Int, m: Int, d: Int): Long = at(y, m, d)

    private fun str(millis: Long): String = fmt.format(java.util.Date(millis))

    private fun alarm(
        h: Int, mi: Int, days: Set<Int> = emptySet(), mode: String? = null, skipped: String? = null
    ) = Alarm(
        id = "t", hour = h, minute = mi,
        repeatDays = days.toMutableSet(), repeatMode = mode, skippedDate = skipped
    )

    // ---------- CnHoliday 数据 ----------

    @Test fun `2025 国庆假期中的周三不是工作日`() {
        assertFalse(CnHoliday.isWorkday("2025-10-01", 3))
        assertTrue(CnHoliday.isHoliday("2025-10-08", 3))
    }

    @Test fun `2025 调休补班的周日是工作日`() {
        assertTrue(CnHoliday.isWorkday("2025-09-28", 7))
        assertTrue(CnHoliday.isWorkday("2025-10-11", 6))
    }

    @Test fun `2026 春节连休九天都不是工作日`() {
        for (d in 15..23) assertFalse("2026-02-$d", CnHoliday.isWorkday("2026-02-$d", ((d - 15) % 7) + 7))
        // 补班日 2/14、2/28 是工作日
        assertTrue(CnHoliday.isWorkday("2026-02-14", 6))
        assertTrue(CnHoliday.isWorkday("2026-02-28", 6))
    }

    @Test fun `未收录年份回退周一至周五规则`() {
        assertTrue(CnHoliday.coversYear(2026))
        assertFalse(CnHoliday.coversYear(2027))
        assertTrue(CnHoliday.isWorkday("2027-03-03", 3))
        assertFalse(CnHoliday.isWorkday("2027-03-06", 6))
    }

    // ---------- nextTriggerMillis：星期规则 ----------

    @Test fun `仅一次闹钟取最近将来时刻`() {
        // 从周三 10:00 看 07:30 → 周四 07:30
        val r = AlarmTime.nextTriggerMillis(alarm(7, 30), at(2026, 3, 4, 10, 0))
        assertEquals("2026-03-05 07:30", str(r))
    }

    @Test fun `工作日闹钟周五触发后跳到下周一`() {
        val a = alarm(7, 30, days = setOf(1, 2, 3, 4, 5))
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 3, 6, 10, 0)) // 周五
        assertEquals("2026-03-09 07:30", str(r)) // 下周一
    }

    @Test fun `每天闹钟今天未过点就今天响`() {
        val a = alarm(7, 30, days = setOf(1, 2, 3, 4, 5, 6, 7))
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 3, 4, 6, 0)) // 周三 06:00
        assertEquals("2026-03-04 07:30", str(r))
    }

    // ---------- nextTriggerMillis：法定规则 ----------

    @Test fun `法定工作日闹钟遇到调休补班的周日照常响`() {
        val a = alarm(7, 30, mode = Alarm.MODE_WORKDAY_CN)
        // 2025-09-26(周五)10:00 起算 → 9/28(周日)补班 → 应在 9/28 响
        val r = AlarmTime.nextTriggerMillis(a, at(2025, 9, 26, 10, 0))
        assertEquals("2025-09-28 07:30", str(r))
    }

    @Test fun `法定工作日闹钟跳过国庆八天`() {
        val a = alarm(7, 30, mode = Alarm.MODE_WORKDAY_CN)
        val r = AlarmTime.nextTriggerMillis(a, at(2025, 9, 30, 10, 0))
        assertEquals("2025-10-09 07:30", str(r)) // 10/9 周四恢复上班
    }

    @Test fun `法定工作日闹钟跳过2026春节九天`() {
        val a = alarm(7, 30, mode = Alarm.MODE_WORKDAY_CN)
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 2, 14, 10, 0)) // 2/14 补班日已过 07:30
        assertEquals("2026-02-24 07:30", str(r)) // 正月初八(2/24)周二上班
    }

    @Test fun `法定节假日闹钟在春节首日响`() {
        val a = alarm(8, 0, mode = Alarm.MODE_HOLIDAY_CN)
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 2, 13, 12, 0))
        assertEquals("2026-02-15 08:00", str(r)) // 2/15 周日是春节假期首日
    }

    @Test fun `法定节假日闹钟跳过补班周末`() {
        val a = alarm(8, 0, mode = Alarm.MODE_HOLIDAY_CN)
        // 2/14(周六)是补班工作日，不是节假日 → 闹钟应跳过它
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 2, 13, 23, 0))
        assertEquals("2026-02-15 08:00", str(r))
    }

    // ---------- 跳过下一次 ----------

    @Test fun `跳过明天后顺延到后天`() {
        val a = alarm(7, 30, days = setOf(1, 2, 3, 4, 5, 6, 7), skipped = "2026-03-05")
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 3, 4, 10, 0))
        assertEquals("2026-03-06 07:30", str(r))
    }

    @Test fun `法定工作日闹钟也可跳过下一次`() {
        val a = alarm(7, 30, mode = Alarm.MODE_WORKDAY_CN, skipped = "2026-03-05")
        val r = AlarmTime.nextTriggerMillis(a, at(2026, 3, 4, 10, 0))
        assertEquals("2026-03-06 07:30", str(r))
    }
}
