package com.dfl.alarm.task

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MathTaskTest {

    @Test fun `生成数量正确且被夹在1到20之间`() {
        assertEquals(3, MathTask.generate(3, 1, seed = 1).size)
        assertEquals(1, MathTask.generate(0, 1, seed = 1).size)
        assertEquals(20, MathTask.generate(99, 1, seed = 1).size)
    }

    @Test fun `难度1只有加法且答案非负不超过10`() {
        val ps = MathTask.generate(50, 1, seed = 42)
        assertTrue(ps.all { it.op == '+' })
        assertTrue(ps.all { it.answer in 0..10 })
    }

    @Test fun `难度2加减结果非负且不超过20`() {
        repeat(50) {
            val ps = MathTask.generate(30, 2, seed = it.toLong())
            assertTrue(ps.all { it.answer >= 0 && it.answer <= 20 })
            assertTrue(ps.all { it.op == '+' || it.op == '-' })
        }
    }

    @Test fun `难度3限加减乘且乘法为九九范围`() {
        repeat(30) {
            val ps = MathTask.generate(30, 3, seed = it.toLong())
            assertTrue(ps.all { it.op == '+' || it.op == '-' || it.op == '×' })
            assertTrue(ps.all { it.answer >= 0 })
        }
    }

    @Test fun `check校验正确`() {
        assertTrue(MathTask.check(MathProblem(3, '+', 5), 8))
        assertFalse(MathTask.check(MathProblem(3, '+', 5), 9))
    }

    @Test fun `减法与乘法答案计算正确`() {
        assertEquals(6, MathProblem(10, '-', 4).answer)
        assertEquals(56, MathProblem(7, '×', 8).answer)
        assertEquals("10 - 4 =", MathProblem(10, '-', 4).display())
    }
}