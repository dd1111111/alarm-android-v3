package com.dfl.alarm.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.dfl.alarm.App
import com.dfl.alarm.MainActivity
import com.dfl.alarm.data.SleepStore
import com.dfl.alarm.schedule.AlarmScheduler
import java.util.Locale

/** 就寝提醒触发：发通知（轻量，不弹全屏），并重设次日。 */
class BedtimeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_BEDTIME) return
        if (!SleepStore.getBedtimeEnabled(context)) return
        val minuteOfDay = SleepStore.getBedtimeMinuteOfDay(context)
        val time = String.format(Locale.US, "%02d:%02d", minuteOfDay / 60, minuteOfDay % 60)

        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, App.CH_MISC)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("该睡觉啦")
            .setContentText("现在 $time，放下手机，晚安 🌙")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(2001, notif)

        // 重设次日
        AlarmScheduler.scheduleBedtime(context, minuteOfDay)
    }
}