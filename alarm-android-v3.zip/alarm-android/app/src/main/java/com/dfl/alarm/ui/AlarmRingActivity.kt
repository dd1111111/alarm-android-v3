package com.dfl.alarm.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.dfl.alarm.R
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.service.AlarmRingService
import com.dfl.alarm.task.MathProblem
import com.dfl.alarm.task.MathTask
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 响铃页：支持三种防赖床任务（算术题 / 摇晃 / 拍照）。
 * 任务完成才允许“停止”；贪睡始终可用（不限次数）。
 */
class AlarmRingActivity : AppCompatActivity(), SensorEventListener {

    private var alarmId: String? = null
    private lateinit var timeView: TextView

    // 任务状态
    private val mathProblems = mutableListOf<MathProblem>()
    private val mathInputs = mutableListOf<EditText>()
    private var shakeCount = 0
    private var shakeTarget = 0
    private var sensorManager: SensorManager? = null
    private var lastShakeTime = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            timeView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 1000)
        }
    }
    private val doneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) stopRing()
        }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        setContentView(R.layout.activity_alarm_ring)

        alarmId = intent.getStringExtra("alarmId")
        val alarm = alarmId?.let { AlarmStore.get(this, it) }

        timeView = findViewById(R.id.ringTime)
        val labelView = findViewById<TextView>(R.id.ringLabel)
        val snoozeBtn = findViewById<Button>(R.id.snoozeBtn)
        val stopBtn = findViewById<Button>(R.id.stopBtn)
        val taskPanel = findViewById<View>(R.id.taskPanel)
        val taskTitle = findViewById<TextView>(R.id.taskTitle)
        val mathContainer = findViewById<LinearLayout>(R.id.mathContainer)
        val mathDoneBtn = findViewById<Button>(R.id.mathDoneBtn)
        val shakeProgress = findViewById<TextView>(R.id.shakeProgress)
        val photoBtn = findViewById<Button>(R.id.photoBtn)

        labelView.text = alarm?.label?.ifBlank { "闹钟" } ?: "闹钟"
        snoozeBtn.text = "😴 贪睡 ${alarm?.snoozeMin ?: 5} 分钟"
        val tip = findViewById<TextView>(R.id.ringTip)
        tip.text = getString(R.string.ring_tip)

        val canSnooze = alarm != null && alarm.allowSnooze && !alarm.snoozed
        snoozeBtn.visibility = if (canSnooze) View.VISIBLE else View.GONE
        snoozeBtn.setOnClickListener { send(AlarmRingService.ACTION_SNOOZE) }
        stopBtn.setOnClickListener { stopRing() }

        when (alarm?.taskType) {
            Alarm.TASK_MATH -> {
                taskPanel.visibility = View.VISIBLE
                mathContainer.visibility = View.VISIBLE
                mathDoneBtn.visibility = View.VISIBLE
                shakeProgress.visibility = View.GONE
                photoBtn.visibility = View.GONE
                stopBtn.visibility = View.GONE
                setupMath(alarm)
            }
            Alarm.TASK_SHAKE -> {
                taskPanel.visibility = View.VISIBLE
                mathContainer.visibility = View.GONE
                mathDoneBtn.visibility = View.GONE
                shakeProgress.visibility = View.VISIBLE
                photoBtn.visibility = View.GONE
                stopBtn.visibility = View.GONE
                setupShake(alarm)
            }
            Alarm.TASK_PHOTO -> {
                taskPanel.visibility = View.VISIBLE
                mathContainer.visibility = View.GONE
                mathDoneBtn.visibility = View.GONE
                shakeProgress.visibility = View.GONE
                photoBtn.visibility = View.VISIBLE
                stopBtn.visibility = View.GONE
                taskTitle.text = getString(R.string.task_title_photo)
                photoBtn.setOnClickListener { launchCamera() }
            }
            else -> {
                taskPanel.visibility = View.GONE
                stopBtn.visibility = View.VISIBLE
            }
        }
    }

    private fun setupMath(alarm: Alarm) {
        val count = alarm.taskParam.coerceIn(1, 20)
        val diff = alarm.taskDifficulty.coerceIn(1, 3)
        mathProblems.clear()
        mathProblems.addAll(MathTask.generate(count, diff))
        val title = findViewById<TextView>(R.id.taskTitle)
        title.text = getString(R.string.task_title_math, count, diff)
        findViewById<TextView>(R.id.shakeProgress).visibility = View.GONE

        val container = findViewById<LinearLayout>(R.id.mathContainer)
        container.removeAllViews()
        val res = resources
        for ((i, p) in mathProblems.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val label = TextView(this).apply {
                text = "${i + 1}.  ${p.display()}"
                textSize = 18f
                setTextColor(0xFFFFFFFF.toInt())
            }
            val input = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(44)).apply { marginStart = dp(8) }
                setBackgroundResource(R.drawable.bg_math_input)
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 18f
            }
            row.addView(label)
            row.addView(input)
            container.addView(row)
            mathInputs.add(input)
        }

        findViewById<Button>(R.id.mathDoneBtn).setOnClickListener { checkMath() }
    }

    private fun checkMath() {
        val allCorrect = mathProblems.indices.all { i ->
            mathInputs[i].text.toString().trim().toIntOrNull() == mathProblems[i].answer
        }
        if (allCorrect) stopRing()
        else Toast.makeText(this, R.string.math_wrong, Toast.LENGTH_SHORT).show()
    }

    private fun setupShake(alarm: Alarm) {
        shakeTarget = alarm.taskParam.coerceIn(1, 100)
        findViewById<TextView>(R.id.taskTitle).text = getString(R.string.task_title_shake, shakeTarget)
        updateShakeProgress()
        sensorManager = getSystemService(SensorManager::class.java)
        sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    private fun launchCamera() {
        try {
            val file = File(cacheDir, "alarm_task_photo.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "无法打开相机", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- 传感器：摇晃检测 ----
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val g = SensorManager.GRAVITY_EARTH
        val acceleration = kotlin.math.sqrt((x * x + y * y + z * z).toDouble()) - g
        val now = System.currentTimeMillis()
        if (acceleration > 11.0 && now - lastShakeTime > 250) {
            lastShakeTime = now
            shakeCount++
            updateShakeProgress()
            if (shakeCount >= shakeTarget) stopRing()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun updateShakeProgress() {
        findViewById<TextView>(R.id.shakeProgress).text = getString(R.string.shake_progress, shakeCount, shakeTarget)
    }

    private fun stopRing() {
        send(AlarmRingService.ACTION_STOP)
    }

    private fun send(action: String) {
        val i = Intent(this, AlarmRingService::class.java)
            .setAction(action)
            .putExtra("alarmId", alarmId)
        ContextCompat.startForegroundService(this, i)
        finish()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this, doneReceiver, IntentFilter(AlarmRingService.ACTION_RING_DONE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // 摇晃任务：回到前台时重新注册传感器
        if (shakeTarget > 0) {
            sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    override fun onStop() {
        try { unregisterReceiver(doneReceiver) } catch (_: Exception) {}
        // 收起页面时注销传感器，避免后台耗电 + 口袋晃动误触发
        try { sensorManager?.unregisterListener(this) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        sensorManager?.unregisterListener(this)
        sensorManager = null
        super.onDestroy()
    }
}