package com.dfl.alarm.model

/**
 * repeatDays 使用 1..7 表示 周一..周日；空集合 = 仅一次。
 * repeatMode 决定重复判定方式：
 * - MODE_DAYS（默认）：按 repeatDays 星期判定
 * - MODE_WORKDAY_CN：法定工作日（含调休补班，跳过法定节假日）
 * - MODE_HOLIDAY_CN：法定节假日（含调休连休）
 */
data class Alarm(
    var id: String,
    var hour: Int,
    var minute: Int,
    var label: String = "",
    var enabled: Boolean = true,
    var repeatDays: MutableSet<Int> = mutableSetOf(),
    var snoozeMin: Int = 5,
    var vibrate: Boolean = true,
    var ramp: Boolean = false,
    var ringtoneUri: String? = null,
    var lastSnoozeUntil: Long = 0L,
    /** 被“跳过下一次”的日期（yyyy-MM-dd），仅对重复闹钟生效 */
    var skippedDate: String? = null,
    /** 重复判定模式，null/空=MODE_DAYS */
    var repeatMode: String? = null,
    /** 防赖床关闭任务：null/"none"=无；TASK_MATH/... */
    var taskType: String? = null,
    /** 任务参数：算术题数量 / 摇晃次数 */
    var taskParam: Int = 3,
    /** 算术题难度 1-3 */
    var taskDifficulty: Int = 1,
    /** 是否允许贪睡 */
    var allowSnooze: Boolean = true,
    /** 本响铃周期是否已贪睡过（限制只能贪睡一次） */
    var snoozed: Boolean = false
) {
    companion object {
        const val MODE_DAYS = "days"
        const val MODE_WORKDAY_CN = "workday_cn"
        const val MODE_HOLIDAY_CN = "holiday_cn"

        const val TASK_NONE = "none"
        const val TASK_MATH = "math"
        const val TASK_SHAKE = "shake"
        const val TASK_PHOTO = "photo"
    }

    fun timeText(): String = String.format("%02d:%02d", hour, minute)

    /** 是否启用防赖床任务。 */
    fun hasTask(): Boolean = taskType != null && taskType != TASK_NONE

    /** 仅一次：无星期选择且非法定工作日/节假日模式。 */
    fun isOnce(): Boolean =
        repeatDays.isEmpty() && (repeatMode.isNullOrEmpty() || repeatMode == MODE_DAYS)
}
