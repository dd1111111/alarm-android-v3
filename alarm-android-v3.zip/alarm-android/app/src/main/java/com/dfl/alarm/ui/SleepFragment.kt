package com.dfl.alarm.ui

import android.app.TimePickerDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.dfl.alarm.R
import com.dfl.alarm.data.SleepStore
import com.dfl.alarm.schedule.AlarmScheduler
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SleepFragment : Fragment() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var statusView: TextView
    private lateinit var durationView: TextView
    private lateinit var subView: TextView
    private lateinit var avgView: TextView
    private lateinit var countView: TextView
    private lateinit var toggleBtn: MaterialButton
    private lateinit var historyView: LinearLayout
    private lateinit var bedtimeSwitch: MaterialSwitch
    private lateinit var bedtimeTime: TextView

    private val tick = object : Runnable {
        override fun run() {
            refreshDuration()
            handler.postDelayed(this, 1000)
        }
    }

    private val dateFmt = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_sleep, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        statusView = view.findViewById(R.id.sleepStatus)
        durationView = view.findViewById(R.id.sleepDuration)
        subView = view.findViewById(R.id.sleepSub)
        avgView = view.findViewById(R.id.sleepAvg)
        countView = view.findViewById(R.id.sleepCount)
        toggleBtn = view.findViewById(R.id.sleepToggle)
        historyView = view.findViewById(R.id.sleepHistory)
        bedtimeSwitch = view.findViewById(R.id.bedtimeSwitch)
        bedtimeTime = view.findViewById(R.id.bedtimeTime)

        toggleBtn.setOnClickListener {
            val cur = SleepStore.current(requireContext())
            if (cur != null) {
                val r = SleepStore.wakeUp(requireContext())
                if (r != null) Toast.makeText(requireContext(), "早上好！睡了 ${hoursText(r.durationMs())}", Toast.LENGTH_SHORT).show()
            } else {
                SleepStore.startSleep(requireContext())
                Toast.makeText(requireContext(), "晚安，已开始记录睡眠", Toast.LENGTH_SHORT).show()
            }
            refresh()
        }

        // 就寝提醒：Switch + 时间选择，独立于起床闹钟
        bedtimeSwitch.isChecked = SleepStore.getBedtimeEnabled(requireContext())
        renderBedtimeTime()
        bedtimeSwitch.setOnCheckedChangeListener { _, checked ->
            val ctx = requireContext()
            val minute = SleepStore.getBedtimeMinuteOfDay(ctx)
            SleepStore.setBedtime(ctx, checked, minute)
            if (checked) AlarmScheduler.scheduleBedtime(ctx, minute) else AlarmScheduler.cancelBedtime(ctx)
            Toast.makeText(ctx, if (checked) "已开启就寝提醒" else "已关闭就寝提醒", Toast.LENGTH_SHORT).show()
        }
        bedtimeTime.setOnClickListener {
            val ctx = requireContext()
            val minute = SleepStore.getBedtimeMinuteOfDay(ctx)
            TimePickerDialog(ctx, { _, h, m ->
                val md = h * 60 + m
                SleepStore.setBedtime(ctx, SleepStore.getBedtimeEnabled(ctx), md)
                if (SleepStore.getBedtimeEnabled(ctx)) AlarmScheduler.scheduleBedtime(ctx, md)
                renderBedtimeTime()
            }, minute / 60, minute % 60, true).show()
        }

        refresh()
    }

    private fun renderBedtimeTime() {
        val minute = SleepStore.getBedtimeMinuteOfDay(requireContext())
        bedtimeTime.text = String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60)
    }

    private fun refresh() {
        refreshDuration()
        refreshStats()
        refreshHistory()
    }

    private fun refreshDuration() {
        val cur = SleepStore.current(requireContext())
        if (cur != null) {
            statusView.text = getString(R.string.sleep_status_sleeping)
            durationView.text = hoursText(System.currentTimeMillis() - cur.sleepTime)
            subView.text = "入睡于 ${dateFmt.format(Date(cur.sleepTime))}"
            toggleBtn.text = getString(R.string.sleep_wake)
        } else {
            statusView.text = getString(R.string.sleep_status_awake)
            toggleBtn.text = getString(R.string.sleep_start)
            val last = SleepStore.load(requireContext()).firstOrNull { !it.isSleeping() }
            if (last != null) {
                durationView.text = hoursText(last.durationMs())
                subView.text = "上次：${dateFmt.format(Date(last.sleepTime))} → ${dateFmt.format(Date(last.wakeTime))}"
            } else {
                durationView.text = "--"
                subView.text = getString(R.string.sleep_no_record)
            }
        }
    }

    private fun refreshStats() {
        val all = SleepStore.load(requireContext()).filter { !it.isSleeping() }
        countView.text = all.size.toString()
        val weekAgo = System.currentTimeMillis() - 7L * 24L * 3600L * 1000L
        val recent = all.filter { it.sleepTime >= weekAgo }
        avgView.text = if (recent.isEmpty()) "--" else hoursText(recent.map { it.durationMs() }.average().toLong())
    }

    private fun refreshHistory() {
        historyView.removeAllViews()
        val records = SleepStore.load(requireContext()).filter { !it.isSleeping() }.take(14)
        if (records.isEmpty()) {
            historyView.addView(TextView(requireContext()).apply {
                text = getString(R.string.sleep_no_record)
                setTextColor(0xFF888888.toInt())
                setPadding(0, 20, 0, 0)
            })
            return
        }
        for (r in records) {
            historyView.addView(TextView(requireContext()).apply {
                text = "${dateFmt.format(Date(r.sleepTime))}  ·  ${hoursText(r.durationMs())}"
                textSize = 15f
                setPadding(0, 14, 0, 0)
                setTextColor(0xFFCCCCCC.toInt())
            })
        }
    }

    private fun hoursText(ms: Long): String {
        val minutes = ms / 60000
        return if (minutes >= 60) "${minutes / 60} 小时 ${minutes % 60} 分" else "$minutes 分钟"
    }

    override fun onResume() {
        super.onResume()
        refresh()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}