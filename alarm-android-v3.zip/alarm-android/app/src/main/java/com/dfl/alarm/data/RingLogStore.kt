package com.dfl.alarm.data

import android.content.Context
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.model.RingLog
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

object RingLogStore {
    private const val PREF = "ring_log_store"
    private const val KEY = "logs"
    private const val MAX = 500
    private val gson = Gson()

    fun load(c: Context): MutableList<RingLog> {
        val json = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<RingLog>>() {}.type
            gson.fromJson<MutableList<RingLog>>(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun addStart(c: Context, alarm: Alarm): RingLog =
        add(c, alarm.id, alarm.label, "start")

    fun addStop(c: Context, alarm: Alarm, event: String): RingLog =
        add(c, alarm.id, alarm.label, event)

    private fun add(c: Context, alarmId: String, label: String, event: String): RingLog {
        val r = RingLog(
            id = UUID.randomUUID().toString(),
            alarmId = alarmId,
            label = label.ifBlank { "闹钟" },
            event = event,
            time = System.currentTimeMillis()
        )
        val list = load(c)
        list.add(0, r)
        if (list.size > MAX) list.subList(MAX, list.size).clear()
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, gson.toJson(list)).apply()
        return r
    }
}