package com.dfl.alarm.model

/** 一条睡眠记录：入睡时间 + 起床时间（0=尚未起床）。 */
data class SleepRecord(
    var id: String,
    var sleepTime: Long,
    var wakeTime: Long = 0L
) {
    fun isSleeping(): Boolean = wakeTime == 0L

    fun durationMs(): Long = if (wakeTime > 0) wakeTime - sleepTime else 0L
}