package com.dfl.alarm.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.dfl.alarm.MainActivity
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.receiver.AlarmReceiver
import com.dfl.alarm.receiver.BedtimeReceiver
import com.dfl.alarm.util.AlarmTime
import java.util.Calendar

/**
 * 精确唤醒：统一使用 AlarmManager.setAlarmClock()。
 */
object AlarmScheduler {
    const val ACTION_FIRE = "com.dfl.alarm.ACTION_FIRE"
    const val ACTION_BEDTIME = "com.dfl.alarm.ACTION_BEDTIME"
    private const val SNOOZE_REQ_OFFSET = 7919
    private const val BEDTIME_REQ = 0x6000

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun firePi(c: Context, alarm: Alarm, snooze: Boolean): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra("alarmId", alarm.id)
            .putExtra("snooze", snooze)
        val req = alarm.id.hashCode() + if (snooze) SNOOZE_REQ_OFFSET else 0
        return PendingIntent.getBroadcast(
            c, req, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun bedtimePi(c: Context): PendingIntent {
        val i = Intent(c, BedtimeReceiver::class.java).setAction(ACTION_BEDTIME)
        return PendingIntent.getBroadcast(
            c, BEDTIME_REQ, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showPi(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            c, 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, alarm: Alarm) {
        cancel(c, alarm)
        if (!alarm.enabled) return
        val triggerAt = nextTriggerMillis(alarm)
        val info = AlarmManager.AlarmClockInfo(triggerAt, showPi(c))
        am(c).setAlarmClock(info, firePi(c, alarm, snooze = false))
    }

    fun scheduleSnooze(c: Context, alarm: Alarm, minutes: Int) {
        val triggerAt = System.currentTimeMillis() + minutes * 60_000L
        alarm.lastSnoozeUntil = triggerAt
        AlarmStore.upsert(c, alarm)
        val info = AlarmManager.AlarmClockInfo(triggerAt, showPi(c))
        am(c).setAlarmClock(info, firePi(c, alarm, snooze = true))
    }

    fun cancel(c: Context, alarm: Alarm) {
        val manager = am(c)
        manager.cancel(firePi(c, alarm, snooze = false))
        manager.cancel(firePi(c, alarm, snooze = true))
        if (alarm.lastSnoozeUntil != 0L) {
            alarm.lastSnoozeUntil = 0L
            AlarmStore.upsert(c, alarm)
        }
    }

    fun rescheduleAll(c: Context) {
        for (a in AlarmStore.load(c)) {
            if (a.enabled) schedule(c, a) else cancel(c, a)
        }
    }

    fun nextTriggerMillis(alarm: Alarm, from: Long = System.currentTimeMillis()): Long =
        AlarmTime.nextTriggerMillis(alarm, from)

    fun skipNext(c: Context, alarm: Alarm) {
        if (alarm.isOnce()) return
        alarm.skippedDate = AlarmTime.dayKey(nextTriggerMillis(alarm))
        AlarmStore.upsert(c, alarm)
        schedule(c, alarm)
    }

    // ---- 就寝提醒（独立于起床闹钟） ----
    fun scheduleBedtime(c: Context, minuteOfDay: Int) {
        cancelBedtime(c)
        val cal = Calendar.getInstance()
        cal.timeInMillis = System.currentTimeMillis()
        cal.set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
        cal.set(Calendar.MINUTE, minuteOfDay % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, showPi(c)), bedtimePi(c))
    }

    fun cancelBedtime(c: Context) {
        am(c).cancel(bedtimePi(c))
    }
}