package com.dfl.alarm.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.dfl.alarm.App
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.data.RingLogStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.schedule.AlarmScheduler
import com.dfl.alarm.ui.AlarmRingActivity

class AlarmRingService : Service() {

    companion object {
        const val ACTION_START = "com.dfl.alarm.service.START"
        const val ACTION_STOP = "com.dfl.alarm.service.STOP"
        const val ACTION_SNOOZE = "com.dfl.alarm.service.SNOOZE"
        const val ACTION_RING_DONE = "com.dfl.alarm.RING_DONE"
        const val NOTIF_ID = 1001
        /** 兜底：无人处理 20 分钟后自动收尾 */
        const val AUTO_STOP_MS = 20 * 60_000L
    }

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var rampRunnable: Runnable? = null
    private var currentId: String? = null
    private var currentAlarm: Alarm? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val id = intent.getStringExtra("alarmId") ?: return START_NOT_STICKY
                val alarm = AlarmStore.get(this, id) ?: return START_NOT_STICKY
                startRing(alarm)
            }
            ACTION_SNOOZE -> {
                handler.removeCallbacksAndMessages(null)
                snoozeAlarm()
            }
            ACTION_STOP -> {
                handler.removeCallbacksAndMessages(null)
                stopAlarm(intent.getStringExtra("alarmId") ?: currentId)
            }
        }
        return START_STICKY
    }

    private fun startRing(alarm: Alarm) {
        currentId = alarm.id
        currentAlarm = alarm
        RingLogStore.addStart(this, alarm) // 记录开启
        val notification = buildNotification(alarm)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        play(alarm)
        vibrate(alarm)
        // 兜底：任务闹钟优先自动贪睡（还能贪睡时），否则停止
        handler.postDelayed({
            val a = currentAlarm
            if (a?.hasTask() == true && a.allowSnooze && !a.snoozed) snoozeAlarm() else stopAlarm(currentId)
        }, AUTO_STOP_MS)
    }

    /** 贪睡：只允许一次（allowSnooze 且未贪睡过），否则视为停止。 */
    private fun snoozeAlarm() {
        val alarm = currentAlarm ?: currentId?.let { AlarmStore.get(this, it) } ?: return
        if (!alarm.allowSnooze || alarm.snoozed) {
            stopAlarm(alarm.id)
            return
        }
        stopAudioVibrate()
        alarm.snoozed = true
        AlarmStore.upsert(this, alarm)
        AlarmScheduler.scheduleSnooze(this, alarm, alarm.snoozeMin)
        RingLogStore.addStop(this, alarm, "snooze")
        finishRing()
    }

    /** 停止响铃。仅一次闹钟停用并取消；重复闹钟清除贪睡残留后重排下一次。 */
    private fun stopAlarm(id: String?) {
        val alarm = id?.let { AlarmStore.get(this, it) } ?: currentAlarm
        stopAudioVibrate()
        if (alarm != null) {
            RingLogStore.addStop(this, alarm, "stop")
            if (alarm.isOnce()) {
                alarm.enabled = false
                alarm.lastSnoozeUntil = 0L
                AlarmStore.upsert(this, alarm)
                AlarmScheduler.cancel(this, alarm)
            } else {
                AlarmScheduler.cancel(this, alarm)
                AlarmScheduler.schedule(this, alarm)
            }
        }
        finishRing()
    }

    private fun play(alarm: Alarm) {
        stopAudioVibrate()
        val uri: Uri = alarm.ringtoneUri?.let { Uri.parse(it) }
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: return
        val r = RingtoneManager.getRingtone(this, uri) ?: return
        ringtone = r
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            r.isLooping = true
            if (alarm.ramp) {
                r.volume = 0.05f
                startRamp(r)
            } else {
                r.volume = 1.0f
            }
        }
        r.play()
    }

    private fun startRamp(r: Ringtone) {
        val start = System.currentTimeMillis()
        val duration = 30_000L
        val run = object : Runnable {
            override fun run() {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return
                val p = ((System.currentTimeMillis() - start).toFloat() / duration).coerceIn(0f, 1f)
                r.volume = 0.05f + 0.95f * p
                if (p < 1f) handler.postDelayed(this, 500)
            }
        }
        rampRunnable = run
        handler.post(run)
    }

    private fun vibrate(alarm: Alarm) {
        if (!alarm.vibrate) return
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION") getSystemService(Vibrator::class.java)
        }
        vibrator = v
        if (v == null || !v.hasVibrator()) return
        val pattern = longArrayOf(0, 400, 200, 400, 200, 800)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION") v.vibrate(pattern, 0)
        }
    }

    private fun stopAudioVibrate() {
        rampRunnable?.let { handler.removeCallbacks(it) }
        rampRunnable = null
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
        try { vibrator?.cancel() } catch (_: Exception) {}
        vibrator = null
    }

    private fun finishRing() {
        sendBroadcast(Intent(ACTION_RING_DONE).setPackage(packageName))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
        currentId = null
        currentAlarm = null
        stopSelf()
    }

    private fun buildNotification(alarm: Alarm): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val contentPi = PendingIntent.getActivity(
            this, alarm.id.hashCode(),
            Intent(this, AlarmRingActivity::class.java)
                .putExtra("alarmId", alarm.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val title = alarm.label.ifBlank { "闹钟" }
        val builder = NotificationCompat.Builder(this, App.CH_RING)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(alarm.timeText())
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(contentPi)
            .setFullScreenIntent(contentPi, true)
        if (alarm.allowSnooze && !alarm.snoozed) {
            val snoozePi = PendingIntent.getService(
                this, alarm.id.hashCode() + 11,
                Intent(this, AlarmRingService::class.java).setAction(ACTION_SNOOZE).putExtra("alarmId", alarm.id),
                flags
            )
            builder.addAction(android.R.drawable.ic_popup_reminder, "贪睡 ${alarm.snoozeMin} 分钟", snoozePi)
        }
        val stopPi = PendingIntent.getService(
            this, alarm.id.hashCode() + 12,
            Intent(this, AlarmRingService::class.java).setAction(ACTION_STOP).putExtra("alarmId", alarm.id),
            flags
        )
        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "停止", stopPi)
        return builder.build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopAudioVibrate()
        super.onDestroy()
    }
}