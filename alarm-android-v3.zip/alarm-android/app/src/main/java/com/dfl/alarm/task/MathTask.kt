package com.dfl.alarm.task

import kotlin.random.Random

/** 一道算术题：a op b = ? */
data class MathProblem(val a: Int, val op: Char, val b: Int) {
    val answer: Int
        get() = when (op) {
            '+' -> a + b
            '-' -> a - b
            '×' -> a * b
            else -> a + b
        }

    fun display(): String = "$a $op $b ="
}

/**
 * 防赖床算术题生成器（纯 Kotlin，可 JVM 单测）。
 * 难度：
 * - 1：十以内加法
 * - 2：20 以内加减（减法结果非负）
 * - 3：100 以内加减 + 九九乘法
 */
object MathTask {
    fun generate(count: Int, difficulty: Int, seed: Long = System.nanoTime()): List<MathProblem> {
        val r = Random(seed)
        val list = mutableListOf<MathProblem>()
        repeat(count.coerceIn(1, 20)) { list.add(one(r, difficulty.coerceIn(1, 3))) }
        return list
    }

    private fun one(r: Random, d: Int): MathProblem = when (d) {
        1 -> {
            val a = r.nextInt(1, 10)
            val b = r.nextInt(1, 11 - a) // 保证 a+b<=10
            MathProblem(a, '+', b)
        }
        2 -> if (r.nextBoolean()) {
            val a = r.nextInt(1, 20)
            val b = r.nextInt(1, 21 - a)
            MathProblem(a, '+', b)
        } else {
            val a = r.nextInt(2, 20)
            val b = r.nextInt(1, a)
            MathProblem(a, '-', b)
        }
        else -> {
            val op = when (r.nextInt(3)) { 0 -> '+'; 1 -> '-'; else -> '×' }
            when (op) {
                '+' -> MathProblem(r.nextInt(1, 100), '+', r.nextInt(1, 100))
                '-' -> {
                    val a = r.nextInt(2, 100)
                    MathProblem(a, '-', r.nextInt(1, a))
                }
                else -> MathProblem(r.nextInt(2, 10), '×', r.nextInt(2, 10))
            }
        }
    }

    fun check(p: MathProblem, input: Int): Boolean = p.answer == input
}