package com.dfl.alarm

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.schedule.AlarmScheduler
import com.dfl.alarm.util.TimeFmt

/**
 * 桌面小组件：显示下一个闹钟（标签 + 下次时间），点击打开 App。
 */
class AlarmWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(context, manager, id)
    }

    override fun onEnabled(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(android.content.ComponentName(context, AlarmWidgetProvider::class.java))
        for (id in ids) update(context, manager, id)
    }

    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_alarm)
            val now = System.currentTimeMillis()
            var best: Long = Long.MAX_VALUE
            var bestA: Alarm? = null
            for (a in AlarmStore.load(context)) {
                if (!a.enabled) continue
                val t = if (a.lastSnoozeUntil > now) a.lastSnoozeUntil else AlarmScheduler.nextTriggerMillis(a, now)
                if (t < best) { best = t; bestA = a }
            }
            if (bestA != null) {
                views.setTextViewText(R.id.widgetLabel, bestA.label.ifBlank { "闹钟" })
                views.setTextViewText(R.id.widgetTime, TimeFmt.nextHint(best, now))
            } else {
                views.setTextViewText(R.id.widgetLabel, "DFL 闹钟")
                views.setTextViewText(R.id.widgetTime, "暂无启用的闹钟")
            }
            val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pi)
            manager.updateAppWidget(id, views)
        }
    }
}