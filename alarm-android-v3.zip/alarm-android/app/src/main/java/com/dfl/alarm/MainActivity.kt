package com.dfl.alarm

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.dfl.alarm.ui.LogFragment
import com.dfl.alarm.ui.SleepFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            showFragment(item.itemId)
            true
        }
        if (savedInstanceState == null) {
            bottomNav.selectedItemId = R.id.nav_alarm
        }

        // Android 13+ 通知权限
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun showFragment(menuId: Int): Fragment {
        val tag = menuId.toString()
        val fm = supportFragmentManager
        var f = fm.findFragmentByTag(tag)
        if (f == null) {
            f = when (menuId) {
                R.id.nav_log -> LogFragment()
                R.id.nav_sleep -> SleepFragment()
                else -> AlarmFragment()
            }
            fm.beginTransaction().add(R.id.fragmentContainer, f, tag).commitNow()
        }
        val tx = fm.beginTransaction()
        for (fr in fm.fragments) tx.hide(fr)
        tx.show(f).commitNow()
        return f
    }
}