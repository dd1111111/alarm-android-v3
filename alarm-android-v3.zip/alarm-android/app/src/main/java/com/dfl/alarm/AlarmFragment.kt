package com.dfl.alarm

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.schedule.AlarmScheduler
import com.dfl.alarm.ui.EditAlarmDialog
import com.dfl.alarm.util.TimeFmt
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmFragment : Fragment() {

    private lateinit var adapter: AlarmAdapter
    private lateinit var nowTime: TextView
    private lateinit var nowDate: TextView
    private lateinit var nextHint: TextView
    private lateinit var emptyTip: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            renderClock()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_alarm, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext()
        nowTime = view.findViewById(R.id.nowTime)
        nowDate = view.findViewById(R.id.nowDate)
        nextHint = view.findViewById(R.id.nextHint)
        emptyTip = view.findViewById(R.id.emptyTip)
        val batteryBtn = view.findViewById<View>(R.id.batteryBtn)

        val list = view.findViewById<RecyclerView>(R.id.alarmList)
        list.layoutManager = LinearLayoutManager(ctx)
        adapter = AlarmAdapter(
            onToggle = { alarm, enabled ->
                alarm.enabled = enabled
                if (!enabled) alarm.lastSnoozeUntil = 0L
                AlarmStore.upsert(ctx, alarm)
                if (enabled) AlarmScheduler.schedule(ctx, alarm) else AlarmScheduler.cancel(ctx, alarm)
                render()
            },
            onClick = { alarm -> openEditor(alarm) }
        )
        list.adapter = adapter

        view.findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener { openEditor(null) }

        view.findViewById<com.google.android.material.button.MaterialButton>(R.id.calendarBtn).setOnClickListener {
            com.dfl.alarm.ui.CalendarEventDialog().show(parentFragmentManager, "calendar")
        }

        batteryBtn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        parentFragmentManager.setFragmentResultListener(EditAlarmDialog.REQUEST_KEY, viewLifecycleOwner) { _, _ -> render() }
        render()
    }

    private fun openEditor(alarm: Alarm?) {
        EditAlarmDialog.newInstance(alarm).show(parentFragmentManager, "edit")
    }

    private fun renderClock() {
        val now = Date()
        nowTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        nowDate.text = SimpleDateFormat("yyyy年M月d日 · EEEE", Locale.CHINA).format(now)
        renderNext()
    }

    private fun renderNext() {
        val now = System.currentTimeMillis()
        var best = Long.MAX_VALUE
        var bestA: Alarm? = null
        for (a in AlarmStore.load(requireContext())) {
            if (!a.enabled) continue
            val t = if (a.lastSnoozeUntil > now) a.lastSnoozeUntil else AlarmScheduler.nextTriggerMillis(a, now)
            if (t < best) { best = t; bestA = a }
        }
        if (bestA == null) {
            nextHint.text = ""
            nextHint.visibility = View.INVISIBLE
        } else {
            nextHint.visibility = View.VISIBLE
            val label = bestA.label.ifBlank { "闹钟" }
            nextHint.text = "下一次：${TimeFmt.nextHint(best, now)}（$label）"
        }
    }

    private fun render() {
        val alarms = AlarmStore.load(requireContext()).sortedWith(compareBy({ it.hour }, { it.minute }))
        adapter.submitList(alarms)
        emptyTip.visibility = if (alarms.isEmpty()) View.VISIBLE else View.GONE
        renderNext()
    }

    override fun onResume() {
        super.onResume()
        render()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    class AlarmAdapter(
        val onToggle: (Alarm, Boolean) -> Unit,
        val onClick: (Alarm) -> Unit
    ) : ListAdapter<Alarm, AlarmAdapter.VH>(DIFF) {
        companion object {
            val DIFF = object : DiffUtil.ItemCallback<Alarm>() {
                override fun areItemsTheSame(a: Alarm, b: Alarm) = a.id == b.id
                override fun areContentsTheSame(a: Alarm, b: Alarm) = a == b
            }
        }

        class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val time: TextView = itemView.findViewById(R.id.aTime)
            val label: TextView = itemView.findViewById(R.id.aLabel)
            val sub: TextView = itemView.findViewById(R.id.aSub)
            val next: TextView = itemView.findViewById(R.id.aNext)
            val sw: MaterialSwitch = itemView.findViewById(R.id.aSwitch)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_alarm, parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            val a = getItem(position)
            h.time.text = a.timeText()
            h.label.text = a.label.ifBlank { "闹钟" }
            val sub = buildList {
                add(TimeFmt.repeatText(a.repeatDays, a.repeatMode))
                add("贪睡${a.snoozeMin}分")
                if (a.ramp) add("渐强")
                if (a.vibrate) add("振动")
                if (!a.ringtoneUri.isNullOrEmpty()) add("自定义铃声")
                if (a.hasTask()) add(
                    when (a.taskType) {
                        Alarm.TASK_MATH -> "算数题"
                        Alarm.TASK_SHAKE -> "摇晃"
                        Alarm.TASK_PHOTO -> "拍照"
                        else -> "任务"
                    }
                )
            }.joinToString(" · ")
            h.sub.text = sub
            h.next.text = if (a.enabled) {
                val now = System.currentTimeMillis()
                val t = if (a.lastSnoozeUntil > now) a.lastSnoozeUntil else AlarmScheduler.nextTriggerMillis(a, now)
                "下次 ${TimeFmt.nextHint(t, now)}"
            } else "已关闭"
            h.itemView.alpha = if (a.enabled) 1f else 0.55f
            h.sw.setOnCheckedChangeListener(null)
            h.sw.isChecked = a.enabled
            h.sw.setOnCheckedChangeListener { _, checked -> onToggle(a, checked) }
            h.itemView.setOnClickListener { onClick(a) }
        }
    }
}