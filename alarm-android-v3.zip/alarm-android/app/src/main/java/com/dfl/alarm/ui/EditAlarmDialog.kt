package com.dfl.alarm.ui

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TimePicker
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.os.bundleOf
import com.dfl.alarm.R
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.schedule.AlarmScheduler
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.gson.Gson
import java.util.UUID

class EditAlarmDialog : BottomSheetDialogFragment() {

    companion object {
        const val REQUEST_KEY = "edit_alarm_result"
        private const val ARG_ALARM = "alarm"

        fun newInstance(alarm: Alarm?): EditAlarmDialog {
            val f = EditAlarmDialog()
            f.arguments = bundleOf(ARG_ALARM to alarm?.let { Gson().toJson(it) })
            return f
        }
    }

    private var editing: Alarm? = null
    private var pickedUri: String? = null

    private val ringtonePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) return@registerForActivityResult
            val data = result.data ?: return@registerForActivityResult
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION") data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (uri != null) {
                pickedUri = uri.toString()
                view?.findViewById<MaterialButton>(R.id.ringtoneBtn)?.text =
                    RingtoneManager.getRingtone(requireContext(), uri)?.getTitle(requireContext()) ?: "已选择铃声"
            }
        }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.dialog_edit_alarm, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()
        editing = arguments?.getString(ARG_ALARM)?.let { Gson().fromJson(it, Alarm::class.java) }
        pickedUri = editing?.ringtoneUri

        val timePicker = view.findViewById<TimePicker>(R.id.timePicker)
        val labelEdit = view.findViewById<TextInputEditText>(R.id.labelEdit)
        val chipDays = view.findViewById<ChipGroup>(R.id.chipDays)
        val chipCnRule = view.findViewById<ChipGroup>(R.id.chipCnRule)
        val chipSnooze = view.findViewById<ChipGroup>(R.id.chipSnooze)
        val chipTask = view.findViewById<ChipGroup>(R.id.chipTask)
        val taskParamRow = view.findViewById<View>(R.id.taskParamRow)
        val taskParamEdit = view.findViewById<TextInputEditText>(R.id.taskParamEdit)
        val chipDiff = view.findViewById<ChipGroup>(R.id.chipDiff)
        val switchVibrate = view.findViewById<MaterialSwitch>(R.id.switchVibrate)
        val switchRamp = view.findViewById<MaterialSwitch>(R.id.switchRamp)
        val ringtoneBtn = view.findViewById<MaterialButton>(R.id.ringtoneBtn)
        val skipBtn = view.findViewById<MaterialButton>(R.id.skipBtn)
        val deleteBtn = view.findViewById<MaterialButton>(R.id.deleteBtn)
        val saveBtn = view.findViewById<MaterialButton>(R.id.saveBtn)
        val cancelBtn = view.findViewById<MaterialButton>(R.id.cancelBtn)

        // 星期与法定规则互斥
        chipCnRule.setOnCheckedStateChangeListener { _, _ ->
            if (chipCnRule.checkedChipId != View.NO_ID) chipDays.clearCheck()
        }
        chipDays.setOnCheckedStateChangeListener { _, _ ->
            if (chipDays.checkedChipIds.isNotEmpty()) chipCnRule.clearCheck()
        }

        fun refreshTaskVisibility() {
            val id = chipTask.checkedChipId
            val math = id == R.id.chipTaskMath
            val shake = id == R.id.chipTaskShake
            taskParamRow.visibility = if (math || shake) View.VISIBLE else View.GONE
            chipDiff.visibility = if (math) View.VISIBLE else View.GONE
        }
        chipTask.setOnCheckedStateChangeListener { _, _ -> refreshTaskVisibility() }

        timePicker.setIs24HourView(true)
        val src = editing
        if (src != null) {
            timePicker.hour = src.hour
            timePicker.minute = src.minute
            labelEdit.setText(src.label)
            switchVibrate.isChecked = src.vibrate
            switchRamp.isChecked = src.ramp
            when (src.repeatMode) {
                Alarm.MODE_WORKDAY_CN -> { chipCnRule.check(R.id.chipWorkday); chipDays.clearCheck() }
                Alarm.MODE_HOLIDAY_CN -> { chipCnRule.check(R.id.chipHoliday); chipDays.clearCheck() }
                else -> for (i in 0 until chipDays.childCount) {
                    val chip = chipDays.getChildAt(i) as? Chip ?: continue
                    chip.isChecked = src.repeatDays.contains(chip.tag.toString().toInt())
                }
            }
            if (src.allowSnooze) checkSnooze(chipSnooze, src.snoozeMin) else chipSnooze.check(R.id.chipS0)
            ringtoneBtn.text = src.ringtoneUri?.let {
                RingtoneManager.getRingtone(ctx, Uri.parse(it))?.getTitle(ctx)
            } ?: "默认闹钟铃声"
            deleteBtn.visibility = View.VISIBLE
            skipBtn.visibility = if (src.isOnce()) View.GONE else View.VISIBLE
            skipBtn.setOnClickListener {
                AlarmScheduler.skipNext(ctx, src)
                Snackbar.make(view, getString(R.string.skip_done), Snackbar.LENGTH_SHORT).show()
                parentFragmentManager.setFragmentResult(REQUEST_KEY, bundleOf())
                dismiss()
            }
            // 任务配置回显
            when (src.taskType) {
                Alarm.TASK_MATH -> chipTask.check(R.id.chipTaskMath)
                Alarm.TASK_SHAKE -> chipTask.check(R.id.chipTaskShake)
                Alarm.TASK_PHOTO -> chipTask.check(R.id.chipTaskPhoto)
                else -> chipTask.check(R.id.chipTaskNone)
            }
            taskParamEdit.setText(src.taskParam.takeIf { it > 0 }?.toString() ?: "3")
            chipDiff.check(
                when (src.taskDifficulty) {
                    3 -> R.id.chipDiff3
                    2 -> R.id.chipDiff2
                    else -> R.id.chipDiff1
                }
            )
            refreshTaskVisibility()
        } else {
            timePicker.hour = 7
            timePicker.minute = 30
            checkSnooze(chipSnooze, 5)
            chipTask.check(R.id.chipTaskNone)
            taskParamEdit.setText("3")
            chipDiff.check(R.id.chipDiff1)
            deleteBtn.visibility = View.GONE
            skipBtn.visibility = View.GONE
            refreshTaskVisibility()
        }

        ringtoneBtn.setOnClickListener {
            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "选择闹钟铃声")
                .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, pickedUri?.let { Uri.parse(it) })
            ringtonePicker.launch(intent)
        }

        saveBtn.setOnClickListener {
            val days = mutableSetOf<Int>()
            for (id in chipDays.checkedChipIds) {
                val chip = view.findViewById<Chip>(id) ?: continue
                chip.tag?.toString()?.toIntOrNull()?.let { days.add(it) }
            }
            val cnMode = when (chipCnRule.checkedChipId) {
                R.id.chipWorkday -> Alarm.MODE_WORKDAY_CN
                R.id.chipHoliday -> Alarm.MODE_HOLIDAY_CN
                else -> null
            }
            val taskType = when (chipTask.checkedChipId) {
                R.id.chipTaskMath -> Alarm.TASK_MATH
                R.id.chipTaskShake -> Alarm.TASK_SHAKE
                R.id.chipTaskPhoto -> Alarm.TASK_PHOTO
                else -> Alarm.TASK_NONE
            }
            val snooze = snoozeFromChips(chipSnooze)
            val alarm = editing ?: Alarm(id = UUID.randomUUID().toString(), hour = 7, minute = 30)
            alarm.hour = timePicker.hour
            alarm.minute = timePicker.minute
            alarm.label = labelEdit.text?.toString()?.trim().orEmpty()
            alarm.allowSnooze = chipSnooze.checkedChipId != R.id.chipS0
            alarm.snoozeMin = snooze
            alarm.vibrate = switchVibrate.isChecked
            alarm.ramp = switchRamp.isChecked
            alarm.ringtoneUri = pickedUri
            alarm.lastSnoozeUntil = 0L
            alarm.skippedDate = null
            if (cnMode != null) { alarm.repeatMode = cnMode; alarm.repeatDays = mutableSetOf() }
            else { alarm.repeatMode = Alarm.MODE_DAYS; alarm.repeatDays = days }
            alarm.taskType = taskType
            alarm.taskParam = taskParamEdit.text?.toString()?.trim()?.toIntOrNull()?.takeIf { it > 0 } ?: 3
            alarm.taskDifficulty = when (chipDiff.checkedChipId) {
                R.id.chipDiff3 -> 3
                R.id.chipDiff2 -> 2
                else -> 1
            }

            AlarmStore.upsert(ctx, alarm)
            if (alarm.enabled) AlarmScheduler.schedule(ctx, alarm) else AlarmScheduler.cancel(ctx, alarm)
            parentFragmentManager.setFragmentResult(REQUEST_KEY, bundleOf())
            dismiss()
        }

        deleteBtn.setOnClickListener {
            val target = editing ?: return@setOnClickListener
            MaterialAlertDialogBuilder(ctx)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_confirm_msg)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete) { _, _ ->
                    AlarmScheduler.cancel(ctx, target)
                    AlarmStore.delete(ctx, target.id)
                    parentFragmentManager.setFragmentResult(REQUEST_KEY, bundleOf())
                    dismiss()
                }
                .show()
        }

        cancelBtn.setOnClickListener { dismiss() }
    }

    private fun checkSnooze(group: ChipGroup, minutes: Int) {
        val id = when (minutes) {
            9 -> R.id.chipS9
            10 -> R.id.chipS10
            15 -> R.id.chipS15
            else -> R.id.chipS5
        }
        group.check(id)
    }

    private fun snoozeFromChips(group: ChipGroup): Int = when (group.checkedChipId) {
        R.id.chipS9 -> 9
        R.id.chipS10 -> 10
        R.id.chipS15 -> 15
        else -> 5
    }
}