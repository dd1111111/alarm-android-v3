package com.dfl.alarm.model

/** 一条闹钟响铃记录：开启/关闭事件。 */
data class RingLog(
    var id: String,
    var alarmId: String,
    var label: String,
    var event: String, // "start" 开启 / "stop" 关闭 / "snooze" 贪睡
    var time: Long
) {
    fun isStart(): Boolean = event == "start"
}