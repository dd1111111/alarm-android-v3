package com.dfl.alarm.data

import android.content.Context
import com.dfl.alarm.model.Alarm
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object AlarmStore {
    private const val PREF = "alarm_store"
    private const val KEY = "alarms"
    private val gson = Gson()

    private fun sp(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Alarm> {
        val json = sp(c).getString(KEY, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<Alarm>>() {}.type
            gson.fromJson<MutableList<Alarm>>(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(c: Context, list: List<Alarm>) {
        sp(c).edit().putString(KEY, gson.toJson(list)).apply()
    }

    fun get(c: Context, id: String): Alarm? = load(c).firstOrNull { it.id == id }

    fun upsert(c: Context, alarm: Alarm) {
        val list = load(c)
        val i = list.indexOfFirst { it.id == alarm.id }
        if (i >= 0) list[i] = alarm else list.add(alarm)
        save(c, list)
    }

    fun delete(c: Context, id: String) {
        save(c, load(c).filterNot { it.id == id })
    }
}
