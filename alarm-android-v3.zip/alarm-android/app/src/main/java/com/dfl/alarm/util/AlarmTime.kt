package com.dfl.alarm.util

import com.dfl.alarm.data.CnHoliday
import com.dfl.alarm.model.Alarm
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * 闹钟触发时间的纯计算逻辑（不依赖 Android 类，便于 JVM 单元测试）。
 * 所有时间运算基于传入的 [Calendar]/毫秒，调用方负责时区。
 */
object AlarmTime {

    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun dayKey(millis: Long): String {
        val c = Calendar.getInstance()
        c.timeInMillis = millis
        return dayFmt.format(c.time)
    }

    /** Calendar.DAY_OF_WEEK(2..7,1=周日) → 1..7(周一..周日) */
    fun calDayToOur(calDay: Int): Int = when (calDay) {
        Calendar.MONDAY -> 1
        Calendar.TUESDAY -> 2
        Calendar.WEDNESDAY -> 3
        Calendar.THURSDAY -> 4
        Calendar.FRIDAY -> 5
        Calendar.SATURDAY -> 6
        Calendar.SUNDAY -> 7
        else -> 1
    }

    /** 闹钟在指定日期是否应该响。 */
    fun matchesDay(alarm: Alarm, dateMillis: Long): Boolean {
        val cal = Calendar.getInstance()
        cal.timeInMillis = dateMillis
        val ourDay = calDayToOur(cal.get(Calendar.DAY_OF_WEEK))
        return when (alarm.repeatMode) {
            Alarm.MODE_WORKDAY_CN -> CnHoliday.isWorkday(dayFmt.format(cal.time), ourDay)
            Alarm.MODE_HOLIDAY_CN -> CnHoliday.isHoliday(dayFmt.format(cal.time), ourDay)
            else -> alarm.repeatDays.contains(ourDay) // MODE_DAYS 或空（仅一次由上层处理）
        }
    }

    /**
     * 计算下一次触发毫秒。
     * - 仅一次：最近的将来那次（不限星期）
     * - 重复（星期/法定工作日/法定节假日）：满足规则且未被“跳过”的最近那次
     *
     * 前瞻窗口 16 天：覆盖春节 9 天连休 + 周末，避免长假期间排不出下一次。
     */
    fun nextTriggerMillis(alarm: Alarm, from: Long = System.currentTimeMillis()): Long {
        for (i in 0..15) {
            val c = Calendar.getInstance()
            c.timeInMillis = from
            c.add(Calendar.DAY_OF_YEAR, i)
            c.set(Calendar.HOUR_OF_DAY, alarm.hour)
            c.set(Calendar.MINUTE, alarm.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= from) continue
            if (alarm.isOnce()) return c.timeInMillis
            if (!matchesDay(alarm, c.timeInMillis)) continue
            if (alarm.skippedDate == dayKey(c.timeInMillis)) continue
            return c.timeInMillis
        }
        return from + 24L * 3600L * 1000L
    }
}
