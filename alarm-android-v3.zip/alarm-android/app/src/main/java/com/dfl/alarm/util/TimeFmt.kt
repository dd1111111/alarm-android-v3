package com.dfl.alarm.util

import com.dfl.alarm.model.Alarm
import java.util.Calendar

object TimeFmt {
    private val CN = mapOf(1 to "一", 2 to "二", 3 to "三", 4 to "四", 5 to "五", 6 to "六", 7 to "日")

    /** Calendar.DAY_OF_WEEK (MONDAY..SUNDAY = 2..7,1) 转成我们的 1..7（周一..周日）。 */
    fun calDayToOur(calDay: Int): Int = when (calDay) {
        Calendar.MONDAY -> 1
        Calendar.TUESDAY -> 2
        Calendar.WEDNESDAY -> 3
        Calendar.THURSDAY -> 4
        Calendar.FRIDAY -> 5
        Calendar.SATURDAY -> 6
        Calendar.SUNDAY -> 7
        else -> 1
    }

    fun repeatText(days: Set<Int>, mode: String? = null): String = when (mode) {
        Alarm.MODE_WORKDAY_CN -> "法定工作日"
        Alarm.MODE_HOLIDAY_CN -> "法定节假日"
        else -> when {
            days.isEmpty() -> "仅一次"
            days.size == 7 -> "每天"
            days == (1..5).toSet() -> "工作日"
            days == setOf(6, 7) -> "周末"
            else -> days.sorted().joinToString("·") { "周" + CN.getValue(it) }
        }
    }

    /** “今天 07:30 · 8 小时 20 分后” */
    fun nextHint(triggerAt: Long, now: Long = System.currentTimeMillis()): String {
        val cal = Calendar.getInstance().apply { timeInMillis = triggerAt }
        val base = Calendar.getInstance()
        val dayLabel = when {
            sameDay(cal, base) -> "今天"
            isTomorrow(cal, base) -> "明天"
            else -> "周" + CN.getValue(calDayToOur(cal.get(Calendar.DAY_OF_WEEK)))
        }
        val mins = ((triggerAt - now) / 60000L).coerceAtLeast(0L)
        val left = if (mins >= 60) "${mins / 60} 小时 ${mins % 60} 分后" else "$mins 分钟后"
        val hm = String.format("%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        return "$dayLabel $hm · $left"
    }

    private fun sameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    private fun isTomorrow(a: Calendar, b: Calendar): Boolean {
        val t = b.clone() as Calendar
        t.add(Calendar.DAY_OF_YEAR, 1)
        return sameDay(a, t)
    }
}
