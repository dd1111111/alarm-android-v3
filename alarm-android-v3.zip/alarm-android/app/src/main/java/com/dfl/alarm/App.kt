package com.dfl.alarm

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.os.Build

class App : Application() {

    companion object {
        const val CH_RING = "alarm_ring"   // 响铃（高优先级、全屏）
        const val CH_MISC = "alarm_misc"   // 其它提醒
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ring = NotificationChannel(CH_RING, "闹钟响铃", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "闹钟到点提醒"
                setSound(null, null) // 声音由前台服务播放，避免重复
                setBypassDnd(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(false) // 振动由服务控制
            }
            val misc = NotificationChannel(CH_MISC, "提醒", NotificationManager.IMPORTANCE_DEFAULT)
            nm.createNotificationChannels(listOf(ring, misc))
        }
    }
}
