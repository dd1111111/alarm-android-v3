package com.dfl.alarm.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.dfl.alarm.R
import com.dfl.alarm.data.RingLogStore
import com.google.android.material.slider.RangeSlider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 记录 Tab：展示闹钟开启/关闭/贪睡记录，用日期区间滑动条筛选。 */
class LogFragment : Fragment() {

    private lateinit var summaryText: TextView
    private lateinit var container: LinearLayout
    private lateinit var slider: RangeSlider
    private val fmt = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_log, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        summaryText = view.findViewById(R.id.logSummary)
        container = view.findViewById(R.id.logContainer)
        slider = view.findViewById(R.id.logRange)
        slider.valueFrom = 0f
        slider.valueTo = 30f
        slider.stepSize = 1f
        slider.values = listOf(0f, 7f) // 默认最近 7 天
        slider.setLabelFormatter { "距今${it.toInt()}天" }
        slider.addOnChangeListener { _, _, _ -> render() }
        render()
    }

    private fun render() {
        val days = slider.values
        val startDays = days[0].toLong().coerceAtLeast(0)
        val endDays = days[1].toLong().coerceAtMost(30)
        val now = System.currentTimeMillis()
        val day = 24L * 3600L * 1000L
        val from = now - startDays * day
        val to = now - endDays * day
        val logs = RingLogStore.load(requireContext()).filter { it.time in from..to }

        val startLabel = if (startDays == 0L) "今天" else "${startDays} 天前"
        val endLabel = if (endDays == 0L) "今天" else "${endDays} 天前"
        summaryText.text = "$startLabel ～ $endLabel · 共 ${logs.size} 条"

        container.removeAllViews()
        if (logs.isEmpty()) {
            container.addView(TextView(requireContext()).apply {
                text = "该时间区间暂无记录"
                setTextColor(0xFF888888.toInt())
                setPadding(0, 24, 0, 0)
            })
            return
        }
        val eventText = mapOf("start" to "🔔 开启", "stop" to "⏹ 关闭", "snooze" to "😴 贪睡")
        val eventColor = mapOf("start" to 0xFF6CCB7F.toInt(), "stop" to 0xFF7FA6FF.toInt(), "snooze" to 0xFFE0A96C.toInt())
        for (log in logs) {
            container.addView(TextView(requireContext()).apply {
                text = "${fmt.format(Date(log.time))}  ·  ${log.label}  ·  ${eventText[log.event] ?: log.event}"
                textSize = 15f
                setPadding(0, 14, 0, 0)
                setTextColor(eventColor[log.event] ?: 0xFFCCCCCC.toInt())
            })
        }
    }
}