package com.dfl.alarm.data

import android.content.Context
import com.dfl.alarm.model.SleepRecord
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

object SleepStore {
    private const val PREF = "sleep_store"
    private const val KEY = "records"
    private val gson = Gson()

    private fun sp(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<SleepRecord> {
        val json = sp(c).getString(KEY, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<SleepRecord>>() {}.type
            gson.fromJson<MutableList<SleepRecord>>(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(c: Context, list: List<SleepRecord>) {
        sp(c).edit().putString(KEY, gson.toJson(list)).apply()
    }

    /** 当前正在睡眠中的记录（有入睡、无起床），最近一条。 */
    fun current(c: Context): SleepRecord? =
        load(c).firstOrNull { it.isSleeping() }

    /** 入睡打卡：新增一条记录。 */
    fun startSleep(c: Context): SleepRecord {
        val r = SleepRecord(id = UUID.randomUUID().toString(), sleepTime = System.currentTimeMillis())
        val list = load(c)
        list.add(0, r)
        save(c, list)
        return r
    }

    /** 起床打卡：给当前睡眠记录打起床时间。 */
    fun wakeUp(c: Context): SleepRecord? {
        val list = load(c)
        val r = list.firstOrNull { it.isSleeping() } ?: return null
        r.wakeTime = System.currentTimeMillis()
        save(c, list)
        return r
    }

    // ---- 就寝提醒设置（独立于起床闹钟） ----
    fun getBedtimeEnabled(c: Context): Boolean = sp(c).getBoolean("bedtime_enabled", false)

    fun getBedtimeMinuteOfDay(c: Context): Int = sp(c).getInt("bedtime_min", 23 * 60)

    fun setBedtime(c: Context, enabled: Boolean, minuteOfDay: Int) {
        sp(c).edit().putBoolean("bedtime_enabled", enabled).putInt("bedtime_min", minuteOfDay).apply()
    }
}