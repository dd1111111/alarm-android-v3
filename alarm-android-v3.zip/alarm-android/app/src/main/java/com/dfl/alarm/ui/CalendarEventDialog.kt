package com.dfl.alarm.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.CalendarContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.dfl.alarm.R
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.model.Alarm
import com.dfl.alarm.schedule.AlarmScheduler
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * P5 智能联动：读取近期日历事件，一键为其创建一次性闹钟（提前 10 分钟提醒）。
 */
class CalendarEventDialog : BottomSheetDialogFragment() {

    private data class Event(val title: String, val begin: Long)

    private var container: LinearLayout? = null
    private val fmt = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadEvents()
            else {
                Toast.makeText(requireContext(), "需要日历权限才能读取日程", Toast.LENGTH_SHORT).show()
                dismiss()
            }
        }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.dialog_calendar_events, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        container = view.findViewById(R.id.calEventList)
        if (hasPermission()) loadEvents()
        else permissionLauncher.launch(Manifest.permission.READ_CALENDAR)
    }

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun loadEvents() {
        val list = container ?: return
        list.removeAllViews()
        val events = queryEvents()
        if (events.isEmpty()) {
            list.addView(TextView(requireContext()).apply {
                text = "未来 7 天没有日程"
                setTextColor(0xFF888888.toInt())
                setPadding(0, 16, 0, 0)
            })
            return
        }
        for (e in events) {
            val tv = TextView(requireContext()).apply {
                text = "${e.title}\n${fmt.format(Date(e.begin))}"
                textSize = 15f
                setPadding(0, 14, 0, 14)
                setTextColor(0xFFCCCCCC.toInt())
                isClickable = true
                setOnClickListener { createAlarm(e) }
            }
            list.addView(tv)
        }
    }

    private fun queryEvents(): List<Event> {
        val now = System.currentTimeMillis()
        val end = now + 7L * 24L * 3600L * 1000L
        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN
        )
        val selection = "${CalendarContract.Instances.BEGIN} >= ? AND ${CalendarContract.Instances.BEGIN} <= ?"
        val args = arrayOf(now.toString(), end.toString())
        val result = mutableListOf<Event>()
        try {
            requireContext().contentResolver.query(
                CalendarContract.Instances.CONTENT_URI, projection, selection, args,
                "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cur ->
                val iTitle = cur.getColumnIndex(CalendarContract.Instances.TITLE)
                val iBegin = cur.getColumnIndex(CalendarContract.Instances.BEGIN)
                while (cur.moveToNext()) {
                    val title = cur.getString(iTitle)?.ifBlank { "日程" } ?: "日程"
                    val begin = cur.getLong(iBegin)
                    result.add(Event(title, begin))
                }
            }
        } catch (_: Exception) {}
        return result
    }

    private fun createAlarm(e: Event) {
        val alarmMillis = e.begin - 10L * 60L * 1000L // 提前 10 分钟
        val cal = Calendar.getInstance()
        cal.timeInMillis = alarmMillis
        val a = Alarm(
            id = UUID.randomUUID().toString(),
            hour = cal.get(Calendar.HOUR_OF_DAY),
            minute = cal.get(Calendar.MINUTE),
            label = e.title,
            enabled = true
        )
        AlarmStore.upsert(requireContext(), a)
        AlarmScheduler.schedule(requireContext(), a)
        Toast.makeText(requireContext(), "已为「${e.title}」设置提醒（${a.timeText()}）", Toast.LENGTH_SHORT).show()
        dismiss()
    }
}