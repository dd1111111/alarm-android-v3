package com.dfl.alarm.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.dfl.alarm.data.AlarmStore
import com.dfl.alarm.schedule.AlarmScheduler
import com.dfl.alarm.service.AlarmRingService

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_FIRE) return
        val id = intent.getStringExtra("alarmId") ?: return
        val isSnooze = intent.getBooleanExtra("snooze", false)
        val alarm = AlarmStore.get(context, id) ?: return

        if (!isSnooze) {
            // 正常触发：开启新响铃周期，重置贪睡标记
            alarm.snoozed = false
            AlarmStore.upsert(context, alarm)
            if (!alarm.isOnce()) {
                AlarmScheduler.schedule(context, alarm)
            }
        }

        val svc = Intent(context, AlarmRingService::class.java)
            .setAction(AlarmRingService.ACTION_START)
            .putExtra("alarmId", id)
            .putExtra("snooze", isSnooze)
        ContextCompat.startForegroundService(context, svc)
    }
}
