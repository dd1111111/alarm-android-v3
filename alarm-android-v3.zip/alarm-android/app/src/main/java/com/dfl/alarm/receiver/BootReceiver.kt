package com.dfl.alarm.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dfl.alarm.schedule.AlarmScheduler

/** 开机 / 改时间 / 改时区 / 覆盖安装后，重排所有启用的闹钟。 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> AlarmScheduler.rescheduleAll(context)
        }
    }
}
