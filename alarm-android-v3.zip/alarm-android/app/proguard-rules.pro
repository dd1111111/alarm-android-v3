# R8 / ProGuard 规则
# Gson 模型类被反射解析，必须保留字段名与泛型签名
-keepattributes Signature
-keep class com.dfl.alarm.model.** { *; }
-keep class * extends com.google.gson.reflect.TypeToken

# 节假日纯数据类（虽无反射，保持稳定）
-keep class com.dfl.alarm.data.CnHoliday { *; }

# Gson 自带规则
-dontwarn sun.misc.**
-keep class com.google.gson.stream.** { *; }
